This folder contains usefull functions, that are available within Matlab, but not
within Octave.
